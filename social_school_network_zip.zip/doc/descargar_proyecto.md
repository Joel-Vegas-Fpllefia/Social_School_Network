# 1 Convertir a zip

Deberemos estar ubicados dentro de la carpeta si queremos usar (.)

```bash
zip -r social_school_network_zip.zip .
```
